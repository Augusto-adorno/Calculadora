import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from './assets/react.svg'
import './App.css'

function App() {
  var [A, setA] = useState(0)
  var [B, setB] = useState(0)
  var [C, setC] = useState(0)
  var [I, setI] = useState('')
  var [R, setR] = useState(null)

  return (
    <>
      <div>
        <a href="https://vite.dev" target="_blank">
          <img src={viteLogo} className="logo" alt="Vite logo" />
        </a>
        <a href="https://react.dev" target="_blank">
          <img src={reactLogo} className="logo react" alt="React logo" />
        </a>
      </div>
      <h1>Calculadora</h1>
      <div className="card">
        <input type="text" name="I" value={I}/> <br/>
        <button onClick={() => setI((I) => I + 1)}>
          1
        </button>
        <button onClick={() => setI((I) => I + 2)}>
          2
        </button>
        <button onClick={() => setI((I) => I + 3)}>
          3
        </button>
        <button onClick={() => setI((I) => I + 4)}>
          4
        </button>
        <button onClick={() => setI((I) => I + 5)}>
          5
        </button> 
        <button onClick={() => setI((I) => I + 6)}>
          6
        </button><br/>
        <button onClick={() => setI((I) => I + 7)}>
          7
        </button>
        <button onClick={() => setI((I) => I + 8)}>
          8
        </button>
        <button onClick={() => setI((I) => I + 9)}>
          9
        </button>
        <button onClick={() => setI((I) => I + 0)}>
          0
        </button>
        <button onClick={() => setI((I) => '')}>
          Clear
        </button><br/>
        <button onClick={() => setA((A) => I)}>
          SetA ({A})
        </button>
        <button onClick={() => setB((B) => I)}>
          SetB ({B})
        </button>
        <button onClick={() => setC((C) => I)}>
          SetC ({C})
        </button>
        <button onClick={() => setR((R) => A + B * C)}>
          Movimento retilíneo uniforme (s = s0 + v . ∆t)
        </button>
        <button onClick={() => setR((R) => A * B)}>
          Movimento Circular Uniforme (v = ω . R)
        </button> <br/>
        <button onClick={() => setR((R) => 0.5 * A * (B*B))}>
          Energia potencial elástica (Eel = 1/2 . k . X^2)
        </button> <br/>
        Resultado = {R}
      </div>
    </>
  )
}

export default App
